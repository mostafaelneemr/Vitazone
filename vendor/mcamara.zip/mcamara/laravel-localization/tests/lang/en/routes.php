<?php

return [
    'about'               => 'about',
    'view'                => 'view/{id}',
    'view_project'        => 'view/{id}/project/{project_id?}',
    'manage'              => 'manage/{file_id?}',
    'hello'               => 'Hello world',
    'test_text'           => 'Test text',
];
